# -*- coding: UTF-8 -*-
# Selector de salida de audio por aplicación para NVDA.
# Desarrollado por Nicolas Alfaro.
# Usa SoundVolumeView.exe como motor externo incluido.

import csv
import os
import re
import subprocess
import shutil
import tempfile
import unicodedata
import threading
import traceback

import globalPluginHandler
import gui
import ui
import wx
from scriptHandler import script

try:
	import addonHandler
except Exception:
	addonHandler = None

_ADDON_NAME = "Selector de salida de audio por aplicación"
_RUNTIME_FOLDER = "SelectorSalidaAudioNVDA"


def _norm_key(text):
	text = (text or "").strip().lower().replace("-", " ").replace("_", " ")
	try:
		text = "".join(c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")
	except Exception:
		pass
	return " ".join(text.split())


def _safe_basename(path_or_name):
	value = (path_or_name or "").strip().strip('"')
	if not value:
		return ""
	base = os.path.basename(value)
	return base or value


def _get_from_row(row, *candidate_names):
	"""Obtiene columnas con nombres variables entre versiones o idiomas de SoundVolumeView."""
	if not row:
		return ""
	normalized = {_norm_key(k): v for k, v in row.items()}
	for name in candidate_names:
		key = _norm_key(name)
		if key in normalized:
			return (normalized[key] or "").strip()
	# Búsqueda flexible por si el encabezado cambia levemente.
	for name in candidate_names:
		key = _norm_key(name)
		for k, v in normalized.items():
			if key and key in k:
				return (v or "").strip()
	return ""


def _human_device_detail(row, friendly_id):
	"""Devuelve una descripción humana del dispositivo usando datos de SoundVolumeView."""
	for col in (
		"Device Name", "Nombre de dispositivo", "Device Description", "Descripcion del dispositivo", "Descripción del dispositivo",
		"Device Friendly Name", "Nombre descriptivo del dispositivo", "Endpoint Name", "Description", "Descripcion", "Descripción",
		"Item ID", "ID del elemento",
	):
		value = _get_from_row(row, col)
		if value and not value.startswith("{") and len(value) < 120:
			return value.strip()
	fid = (friendly_id or "").strip()
	if not fid:
		return ""
	sep_match = re.search(r"\\Device\\", fid, re.I)
	if sep_match:
		detail = fid[:sep_match.start()].strip(" \\")
		if detail:
			return detail
	parts = [x.strip() for x in re.split(r"[\\/]+", fid) if x.strip()]
	generic = set([
		"device", "render", "capture", "speakers", "speaker", "headphones", "headphone",
		"altavoces", "auriculares", "microphone", "microfono", "micrófono", "salida", "entrada",
	])
	for part in parts:
		if _norm_key(part) not in generic and not part.startswith("{"):
			return part
	return ""


def _make_device_display(row, name, friendly_id, state):
	base = (name or "Dispositivo de salida").strip()
	detail = _human_device_detail(row, friendly_id)
	display = base
	if detail and _norm_key(detail) not in _norm_key(base) and _norm_key(base) not in _norm_key(detail):
		display = "%s - %s" % (base, detail)
	state_norm = _norm_key(state)
	if state and state_norm not in ("active", "activo"):
		display = "%s (%s)" % (display, state)
	return display


def _run_hidden(args, timeout=12):
	startupinfo = None
	if os.name == "nt":
		startupinfo = subprocess.STARTUPINFO()
		startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
	try:
		return subprocess.run(
			args,
			stdout=subprocess.PIPE,
			stderr=subprocess.PIPE,
			stdin=subprocess.DEVNULL,
			startupinfo=startupinfo,
			timeout=timeout,
			text=True,
			encoding="utf-8",
			errors="replace",
		)
	except Exception as e:
		class Result:
			returncode = 999
			stdout = ""
			stderr = str(e)
		return Result()


class SoundVolumeViewBridge:
	"""Puente mínimo para exportar dispositivos/sesiones y aplicar /SetAppDefault."""
	def __init__(self):
		self.searchedPaths = []
		self.exe = self._find_exe()

	def _candidate_roots(self):
		roots = []
		plugin_dir = os.path.abspath(os.path.dirname(__file__))
		cur = plugin_dir
		for _ in range(5):
			if cur not in roots:
				roots.append(cur)
			parent = os.path.abspath(os.path.join(cur, os.pardir))
			if parent == cur:
				break
			cur = parent
		if addonHandler:
			try:
				addon = addonHandler.getCodeAddon()
				addon_path = getattr(addon, "path", "") if addon else ""
				if addon_path and addon_path not in roots:
					roots.insert(0, addon_path)
			except Exception:
				pass
		return roots

	def _find_exe(self):
		paths = []
		for root in self._candidate_roots():
			paths.extend([
				os.path.join(root, "SoundVolumeView.exe"),
				os.path.join(root, "tools", "SoundVolumeView.exe"),
				os.path.join(root, "globalPlugins", "tools", "SoundVolumeView.exe"),
			])
		seen = set()
		unique = []
		for p in paths:
			lp = p.lower()
			if lp not in seen:
				seen.add(lp)
				unique.append(p)
		self.searchedPaths = unique
		for p in unique:
			if p and os.path.isfile(p):
				return p
		return ""

	def available(self):
		return bool(self.exe and os.path.isfile(self.exe))

	def _runtime_exe(self):
		"""Ejecuta SoundVolumeView desde una carpeta temporal sin archivo de idioma.
		Así los encabezados exportados salen en inglés y el complemento los interpreta mejor.
		"""
		self.exe = self._find_exe()
		if not self.available():
			return ""
		try:
			base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
			run_dir = os.path.join(base, _RUNTIME_FOLDER, "runtime")
			os.makedirs(run_dir, exist_ok=True)
			dst = os.path.join(run_dir, "SoundVolumeView.exe")
			if (not os.path.isfile(dst)) or os.path.getsize(dst) != os.path.getsize(self.exe):
				shutil.copy2(self.exe, dst)
			for lng in ("SoundVolumeView_lng.ini", "soundvolumeview_lng.ini"):
				lng_path = os.path.join(run_dir, lng)
				if os.path.exists(lng_path):
					os.remove(lng_path)
			return dst
		except Exception:
			return self.exe

	def export_rows(self):
		run_exe = self._runtime_exe()
		if not run_exe:
			return []
		fd, path = tempfile.mkstemp(prefix="selector_salida_audio_", suffix=".csv")
		os.close(fd)
		try:
			result = _run_hidden([run_exe, "/SaveFileEncoding", "3", "/scomma", path], timeout=15)
			if result.returncode not in (0, None):
				raise RuntimeError(result.stderr or "SoundVolumeView no pudo exportar la lista de audio.")
			with open(path, "r", encoding="utf-8-sig", newline="") as f:
				return list(csv.DictReader(f))
		finally:
			try:
				os.remove(path)
			except Exception:
				pass

	def get_devices_and_apps(self):
		rows = self.export_rows()
		devices = []
		apps = []
		seen_devices = set()
		seen_apps = set()
		for row in rows:
			type_value = _get_from_row(row, "Type", "Tipo")
			direction = _get_from_row(row, "Direction", "Direccion", "Dirección")
			name = _get_from_row(row, "Name", "Nombre", "Item Name", "Application Name")
			friendly_id = _get_from_row(
				row,
				"Command-Line Friendly ID",
				"Command-LineFriendlyID",
				"Command Line Friendly ID",
				"Friendly ID",
				"ID sencilla de secuencia de comandos",
				"ID de secuencia de comandos",
				"ID",
			)
			state = _get_from_row(row, "Device State", "Estado de dispositivo", "State", "Estado")
			lower_type = _norm_key(type_value)
			lower_direction = _norm_key(direction)
			lower_friendly = (friendly_id or "").lower()

			is_device = ("device" in lower_type) or ("dispositivo" in lower_type)
			is_app = ("application" in lower_type) or ("aplicacion" in lower_type) or ("app" == lower_type)
			is_render = ("\\render" in lower_friendly) or ("render" in lower_direction) or ("salida" in lower_direction) or ("reproduccion" in lower_direction)
			is_capture = ("\\capture" in lower_friendly) or ("capture" in lower_direction) or ("captur" in lower_direction) or ("microfono" in _norm_key(name))

			if is_device and (is_render or not is_capture):
				cmd_id = friendly_id or name
				bad_state = _norm_key(state)
				if cmd_id and cmd_id not in seen_devices and not any(x in bad_state for x in ("disabled", "inhabilitado", "deshabilitado", "unplugged", "desconectado")):
					seen_devices.add(cmd_id)
					display = _make_device_display(row, name, friendly_id, state)
					devices.append({"display": display, "id": cmd_id})
			elif is_app:
				process_path = _get_from_row(row, "Process Path", "Ruta de proceso", "Ruta del proceso")
				process_name = _get_from_row(row, "Process Name", "Nombre de proceso", "Nombre del proceso")
				process_id = _get_from_row(row, "Process ID", "ID de proceso", "PID")
				if not process_name and process_path:
					process_name = _safe_basename(process_path)
				if not process_name:
					match = re.search(r"([A-Za-z0-9_. -]+\.exe)", " ".join([name, friendly_id, process_path]), re.I)
					if match:
						process_name = match.group(1).strip()
				if not process_name and name.lower().endswith(".exe"):
					process_name = name
				process_for_cmd = process_name or process_id
				if not process_for_cmd:
					continue
				# Seguridad: no ofrecemos mover NVDA, así el usuario no queda sin voz por accidente.
				if str(process_for_cmd).lower() == "nvda.exe":
					continue
				key = str(process_for_cmd).lower()
				if key in seen_apps:
					continue
				seen_apps.add(key)
				display = process_name or name or process_id
				if name and name.lower() != display.lower():
					display = "%s - %s" % (display, name)
				apps.append({"display": display, "process": process_for_cmd})

		counts = {}
		for dev in devices:
			key = dev["display"].lower()
			counts[key] = counts.get(key, 0) + 1
		seen_display = {}
		for dev in devices:
			key = dev["display"].lower()
			if counts.get(key, 0) > 1:
				seen_display[key] = seen_display.get(key, 0) + 1
				dev["display"] = "%s %d" % (dev["display"], seen_display[key])
		devices.sort(key=lambda x: x["display"].lower())
		apps.sort(key=lambda x: x["display"].lower())
		return devices, apps

	def set_app_default(self, device_id, process):
		run_exe = self._runtime_exe()
		if not run_exe:
			raise RuntimeError("No se encontró SoundVolumeView.exe")
		if str(process).lower() == "nvda.exe":
			raise RuntimeError("Por seguridad, este complemento no cambia la salida de NVDA.")
		result = _run_hidden([run_exe, "/SetAppDefault", device_id, "all", str(process)], timeout=12)
		if result.returncode not in (0, None):
			raise RuntimeError(result.stderr or result.stdout or "error desconocido")


class AudioRouterDialog(wx.Dialog):
	def __init__(self, parent):
		super(AudioRouterDialog, self).__init__(parent, title=_ADDON_NAME, size=(760, 520))
		self.bridge = SoundVolumeViewBridge()
		self.devices = []
		self.apps = []
		panel = wx.Panel(self)
		main = wx.BoxSizer(wx.VERTICAL)

		intro = wx.StaticText(panel, label="Elige una aplicación con audio activo y el dispositivo por donde debe salir. NVDA queda oculto por seguridad.")
		main.Add(intro, 0, wx.ALL | wx.EXPAND, 10)

		self.status = wx.StaticText(panel, label="Cargando...")
		main.Add(self.status, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.EXPAND, 10)

		lists = wx.BoxSizer(wx.HORIZONTAL)
		left = wx.BoxSizer(wx.VERTICAL)
		left.Add(wx.StaticText(panel, label="Aplicaciones con audio:"), 0, wx.BOTTOM, 4)
		self.appsList = wx.ListBox(panel, style=wx.LB_SINGLE)
		left.Add(self.appsList, 1, wx.EXPAND)
		right = wx.BoxSizer(wx.VERTICAL)
		right.Add(wx.StaticText(panel, label="Dispositivos de salida:"), 0, wx.BOTTOM, 4)
		self.devicesList = wx.ListBox(panel, style=wx.LB_SINGLE)
		right.Add(self.devicesList, 1, wx.EXPAND)
		lists.Add(left, 1, wx.RIGHT | wx.EXPAND, 8)
		lists.Add(right, 1, wx.LEFT | wx.EXPAND, 8)
		main.Add(lists, 1, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.EXPAND, 10)

		buttons = wx.BoxSizer(wx.HORIZONTAL)
		self.applyBtn = wx.Button(panel, label="Enviar aplicación al dispositivo")
		self.refreshBtn = wx.Button(panel, label="Actualizar listas")
		closeBtn = wx.Button(panel, wx.ID_CANCEL, label="Cerrar")
		for btn in (self.applyBtn, self.refreshBtn, closeBtn):
			buttons.Add(btn, 0, wx.RIGHT, 6)
		main.Add(buttons, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

		panel.SetSizer(main)
		self.Bind(wx.EVT_BUTTON, self.on_apply, self.applyBtn)
		self.Bind(wx.EVT_BUTTON, self.on_refresh, self.refreshBtn)
		self.Bind(wx.EVT_CLOSE, self.on_close)
		wx.CallAfter(self.refresh)

	def _set_status(self, text):
		self.status.SetLabel(text)
		try:
			ui.message(text)
		except Exception:
			pass

	def refresh(self):
		self.bridge.exe = self.bridge._find_exe()
		self.appsList.Clear()
		self.devicesList.Clear()
		self.applyBtn.Enable(False)
		if not self.bridge.available():
			self._set_status("No encontré SoundVolumeView.exe incluido. El complemento no puede leer aplicaciones ni dispositivos.")
			return
		self._set_status("Buscando aplicaciones y dispositivos de audio...")
		def worker():
			try:
				devices, apps = self.bridge.get_devices_and_apps()
				wx.CallAfter(self._populate, devices, apps, None)
			except Exception:
				wx.CallAfter(self._populate, [], [], traceback.format_exc())
		threading.Thread(target=worker, daemon=True).start()

	def _populate(self, devices, apps, error):
		if error:
			self._set_status("Error leyendo audio. Prueba actualizar listas.")
			return
		self.devices = devices
		self.apps = apps
		for app in apps:
			self.appsList.Append(app["display"])
		for dev in devices:
			self.devicesList.Append(dev["display"])
		if apps:
			self.appsList.SetSelection(0)
		if devices:
			self.devicesList.SetSelection(0)
		self.applyBtn.Enable(bool(apps and devices))
		self._set_status("Listo. Aplicaciones: %d. Dispositivos: %d." % (len(apps), len(devices)))

	def on_refresh(self, evt):
		self.refresh()

	def on_apply(self, evt):
		app_index = self.appsList.GetSelection()
		dev_index = self.devicesList.GetSelection()
		if app_index == wx.NOT_FOUND or dev_index == wx.NOT_FOUND:
			self._set_status("Elige una aplicación y un dispositivo.")
			return
		app = self.apps[app_index]
		dev = self.devices[dev_index]
		self.applyBtn.Enable(False)
		self._set_status("Aplicando salida de %s hacia %s..." % (app["display"], dev["display"]))
		def worker():
			try:
				self.bridge.set_app_default(dev["id"], app["process"])
				wx.CallAfter(self._apply_done, "Hecho: %s saldrá por %s." % (app["display"], dev["display"]))
			except Exception as e:
				wx.CallAfter(self._apply_done, "No pude aplicar el cambio: %s" % e)
		threading.Thread(target=worker, daemon=True).start()

	def _apply_done(self, msg):
		self.applyBtn.Enable(True)
		self._set_status(msg)

	def on_close(self, evt):
		self.Destroy()


class GlobalPlugin(globalPluginHandler.GlobalPlugin):
	__gestures = {
		"kb:NVDA+shift+a": "openAudioRouter",
	}

	@script(
		description="Abre el selector de salida de audio por aplicación.",
		gesture="kb:NVDA+shift+a",
	)
	def script_openAudioRouter(self, gesture):
		ui.message("Abriendo selector de salida de audio")
		wx.CallAfter(self._show_dialog)

	def _show_dialog(self):
		try:
			d = AudioRouterDialog(gui.mainFrame)
			d.Show()
		except Exception as e:
			ui.message("No pude abrir el selector de audio: %s" % e)
